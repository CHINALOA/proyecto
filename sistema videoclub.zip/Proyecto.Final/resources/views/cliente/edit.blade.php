<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <link href="{{ asset('css/editcliente.css') }}" rel="stylesheet">
</head>

<header>
<br>
  <div class="jumbotron jumbotronEncabezado text-center">
      <h1 class="display-4 textoEncabezado">¡ Editar Clientes !</h1>
      <br>
    </div>
</header>
<body>

    <div class="container">
        <div class="row vh-100 justify-content-center aling-items-center">
        <div class="col-md-offset-5 col-md-4 text-left">
    <form action="{{route('cliente.update',$cliente->id)}}" method="post">
        @csrf
        @method('PUT')
        <br>
        <div class="form-login">

            @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{$error}}</li>
                    @endforeach
                </ul>
            </div>

            @endif
            <div class="form-group">
            <label for="nombre">Nombre</label>
            <input type="text" class="form-control" name='nombre' required maxlength="50" value="{{$cliente->nombre}}">
        </div>

            <div class="form-group">
                <label for="apellido">Apellido</label>
                <input type="text" class="form-control" name='apellido'  required maxlength="50" value="{{$cliente->apellido}}">
            </div>

        <div class="form-group">
            <label for="documento">Documentos</label>
            <input type="text" class="form-control" name='documento'  required maxlength="50" value="{{$cliente->documento}}">
        </div>
        <div class="form-group">
            <label for="telefono">Telefono</label>
            <input type="text" class="form-control" name='telefono'  required maxlength="50" value="{{$cliente->telefono}}">
        </div>
        <div class="form-group">
            <label for="email">correo electronico</label>
            <input type="text" class="form-control" name='email'  required maxlength="50" value="{{$cliente->email}}">
        </div>
        <div class="form-group">
            <label for="direccion">Direccion</label>
            <input type="text" class="form-control" name='direccion'  required maxlength="50" value="{{$cliente->direccion}}">
        </div>
        <div class="form-group">
            <br>
            <p align="right">
                <input type="submit" class="btn btn-primary" value="Guardar">
            <input type="reset" class="btn btn-warning" value="cancelar">
            <a href="{{route('cliente.index')}}" class="btn btn-info">Regresar</a>
            </p>


        </div>
</form>

        </div>
              </div>
            </div>

            </body>
</html>
