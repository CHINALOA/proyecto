<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <link href="{{ asset('css/altacliente.css') }}" rel="stylesheet">

</head>

<header>

  <div class="jumbotron jumbotronEncabezado text-center">
      <br>
      <h1 class="display-4 textoEncabezado">¡ Alta Clientes !</h1>
      <p class="lead textoEncabezado"></p>

    </div>
</header>
<body>

    <div class="container">
        <div class="row vh-100 justify-content-center aling-items-center">
        <div class="col-md-offset-5 col-md-4 text-left">
    <form action="{{route('cliente.store')}}" method="post">
        @csrf
        <div class="form-login">
            @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{$error}}</li>
                    @endforeach
                </ul>
            </div>

            @endif
            <div class="form-group">
            <label for="nombre">Nombre</label>
            <input type="text" class="form-control input-sm chat-input" name='nombre' placeholder="Nombre" value="{{old('nombre')}}" required maxlength="50">
           </div>

            <div class="form-group ">
                <label for="apellido">Apellido</label>
                <input type="text" class="form-control input-sm chat-input" name='apellido' placeholder="Apellido" value="{{old('apellido')}}" required maxlength="50">
            </div>

          <div class="form-group ">
            <label for="documento">Documentos</label>
            <input type="text" class="form-control input-sm chat-input" name='documento' placeholder="Documentos" value="{{old('documento')}}" required maxlength="50">
           </div>
          <div class="form-group ">
            <label for="telefono">Telefono</label>
            <input type="text" class="form-control input-sm chat-input" name='telefono' placeholder="Telefono" value="{{old('telefono')}}" required maxlength="50">
           </div>
           <div class="form-group ">
            <label for="email">Correo electronico</label>
            <input type="text" class="form-control input-sm chat-input" name='email' placeholder="Email" value="{{old('email')}}" required maxlength="50">
           </div>
           <div class="form-group">
            <label for="direccion">Direccion</label>
            <input type="text" class="form-control input-sm chat-input" name='direccion' placeholder="Direccion" value="{{old('direccion')}}" required maxlength="50">
          </div>
           <div class="form-group">
            <br>
            <p align="right">
                <input type="submit" class="btn btn-primary" value="Guardar">
            <input type="reset" class="btn btn-success" value="Vaciar">
          <a href="{{route('cliente.index')}}" class="btn btn-dark">Regresar</a>
            </p>

           </div>
           </div>
</form>

             </div>
              </div>
            </div>

            </body>
</html>
