<!DOCTYPE html>
<html lang="en">
<head>


    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Peliculas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <link href="{{ asset('css/menucliente.css') }}" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <a class="navbar-brand" >
   </a>
    <div class="container" >
      <ul class="nav ">
        <li class="nav-item">
                <a href="{{route('categoria.create')}}" class="btn btn-success">Nueva pelicula </a>
          </li>
          <li class="nav-item">
<h1>|</h1>
          </li>
          <li class="nav-item">
            <a href="{{route('categoria.index')}}" class="btn btn-info">Regresar</a>
        </li>
        <li class="nav-item">
            <h1>|</h1>
       </li>
       <li class="nav-item">
        <a href="{{route('home')}}" class="btn btn-light">Inicio</a>
    </li>

        </ul>
        </div>


    <div class="form-row">
      <form action="{{route('categoria.index')}}" method="GET" >
            <input type="text" class="form-control me-5" name="texto" value="{{$texto}}">
            </div>
            <input type="submit" class="btn btn-primary" value="Buscar">

      </form>
    </div>
  </div>
</nav>

    <div class="container jumbotronEncabezado">
        <div class="row">
            <div class="col-xl-12 ">


            <div class="col-xl12">
                <div class="table-responsive">
                    <br>
                    <table class="form-login table table-sm">
                        <thead>
                            <tr>
                                <th>Opciones</th>
                                <th>ID</th>
                                <th>CATEGORIAS</th>
                            </tr>
                        </thead>
                         <tbody>
                             @if(count($categorias)<=0)
                             <tr>
                                 <td colspan="8">No hay resultados</td>
                             </tr>
                              @else

                             @foreach ($categorias as $categoria)
                        <tr>
                            <td>

                                <div class="container">
                                    <ul class="nav ">
                                      <li class="nav-item">
                                        <a href="{{route('categoria.edit', $categoria->id)}}" style="margin: 3px" class="btn btn-warning btn-sm">Editar</a>
                                    </li>
                                      <li class="nav-item">
                                        <button type="button" style="margin: 3px" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#modal-delete-{{$categoria->id}}">
                                            Eliminar
                                          </button>
                                      </li>

                                    </ul>
                                  </div>

                            </td>
                            <td>{{$categoria->id}}</td>
                            <td>{{$categoria->categoria}}</td>



                        </tr>
                        @include('categoria.delete')
                        @endforeach
                        @endif
                         </tbody>
                    </table>
                    {{$categorias->links()}}

                </div>

            </div>

        </div>
        </div>
    </div>

</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-kQtW33rZJAHjgefvhyyzcGF3C5TFyBQBA13V1RKPf4uH+bwyzQxZ6CmMZHmNBEfJ" crossorigin="anonymous"></script>
</html>
