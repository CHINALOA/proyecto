<?php $__env->startSection('content'); ?>
<!doctype html>
<html lang="es">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('css/menu.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Olmaton - Plantilla Laravel</title>
  </head>
  <body>
      <br>
    <header>
    <nav class="container navbar navbar-expand-lg navbar-light">
      <a class="navbar-brand" >
      <img src="<?php echo e(asset('img/logo.png')); ?>" height="70px" alt="Inicio">
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#toggle" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">

          </li>
        </ul>
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('cliente.index')); ?>">CLIENTES</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('pelicula.index')); ?>"> PELICULAS</a>
          </li>
          <li class="nav-item">
            <a class="nav-link smooth-scroll " href="<?php echo e(route('categoria.index')); ?>"> CATEGORIA</a>
          </li>

          <li class="nav-item">
            <a class="nav-link smooth-scroll " href=""> CONTACTO</a>
          </li>
          <li class="nav-item dropdown">
            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                <?php echo e(Auth::user()->name); ?>

            </a>

            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault();
                                 document.getElementById('logout-form').submit();">
                    <?php echo e(__('SALIR')); ?>

                </a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </li>
        </ul>
      </div>
    </nav>
    </header>
    <div>
        <?php echo $__env->yieldContent('contenedor'); ?>
    </div>
    <br>


    <div class="wrapper">
        <div class="slider" id="slider">
          <ul class="slides">
            <li class="slide" id="slide1">
              <a href="#">
                <p class="caption">TERROR</p>
                <img src="https://s3-eu-west-1.amazonaws.com/abandomedia/db/poster/db_posters_40846.jpg" width="500" height="450" alt="photo 1">
              </a>
            </li>
            <li class="slide" id="slide2">
              <a href="#">
                <p class="caption">ACCIÓN</p>
                <img src="http://sp0.cinedor.es/745/banner-horizontal-the-gangster-squad-brigada-de-elite-con-robert-patrick-767.jpg" width="500" height="450" alt="photo 2">
              </a>
            </li>
            <li class="slide" id="slide3">
              <a href="#">
                <p class="caption">AVENTURA</p>
                <img src="https://www.3djuegos.com/files_foros/6a/6adm.png" width="500" height="450" alt="photo 3">
              </a>
            </li>
            <li class="slide" id="slide4">
              <a href="#">
                <p class="caption">ROMANCE</p>
                <img src="https://culturizarte.cl/wp-content/uploads/2019/12/MARRIAGE_STORY_Horizontal_TEASER_RGB_Chile_LASqq.jpg" width="500" height="450" alt="photo 4">
              </a>
            </li>
            <li class="slide" id="slide5">
              <a href="#">
                 <p class="caption">COMEDIA</p>
                 <img src="https://img.vavel.com/hubie-halloween-poster-1603025606927.jpg" width="500" height="450" alt="photo 5">
              </a>
            </li>
            <li class="slide" id="slide6">
              <a href="#">
                <p class="caption">INFANTIL</p>
                <img src="http://soundtrackfest.com/wp-content/uploads/2019/12/LionKing2019-LiveToPicture-WorldPremiere-Banner.jpg" width="500" height="450" alt="photo 1">
              </a>
            </li>
          </ul>
          <ul class="slider-controler">
            <li><a href="#slide1">&bullet;</a></li>
            <li><a href="#slide2">&bullet;</a></li>
            <li><a href="#slide3">&bullet;</a></li>
            <li><a href="#slide4">&bullet;</a></li>
            <li><a href="#slide5">&bullet;</a></li>
            <li><a href="#slide6">&bullet;</a></li>

          </ul>
        </div>
      </div>
</body>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto.Final\resources\views/home.blade.php ENDPATH**/ ?>