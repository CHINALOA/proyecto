<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <link href="<?php echo e(asset('css/altapelicula.css')); ?>" rel="stylesheet">

</head>

<header>

  <div class="jumbotron jumbotronEncabezado text-center">
      <br>
      <h1 class="display-4 textoEncabezado">¡ Peliculas nuevas!</h1>
      <p class="lead textoEncabezado"></p>
    </div>
</header>
<body>

    <div class="container">
<br>
      </div>
    <div class="container">
        <div class="row vh-100 justify-content-center aling-items-center">
        <div class="col-md-offset-5 col-md-4 text-left">
    <form action="<?php echo e(route('categoria.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-login">

            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <?php endif; ?>

            <div class="form-group ">
                <label for="categoria">Categorias</label>
                <input type="text" class="form-control input-sm chat-input" name='categoria' placeholder="Categoria" value="<?php echo e(old('categoria')); ?>" required maxlength="50">
            </div>
           <div class="form-group">
            <br>
            <p align="right">
                <input type="submit" class="btn btn-primary" value="Guardar">
            <input type="reset" class="btn btn-success" value="Vaciar">
          <a href="<?php echo e(route('categoria.index')); ?>" class="btn btn-dark">Regresar</a>
            </p>


           </div>
           </div>
</form>

             </div>
              </div>
            </div>

            </body>
</html>
<?php /**PATH C:\laragon\www\Proyecto.Final\resources\views/categoria/create.blade.php ENDPATH**/ ?>