<?php

namespace App\Http\Controllers;

use App\Models\Pelicula;
use Illuminate\Validation\ValidationException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use function GuzzleHttp\Promise\all;

class PeliculaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $texto=trim($request->get('texto'));
     $peliculas=DB::table('pelicula')
    ->select('id', 'titulo','foto', 'resumen', 'año',)
    ->where('titulo', 'LIKE', '%'.$texto.'%')
    ->orWhere('año', 'LIKE', '%'.$texto. '%')
    ->orderBy('id', 'asc')
    ->paginate(10);
     return view('pelicula.index',compact('peliculas', 'texto'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {

        return view('pelicula.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $request->validate([
            'titulo' => 'required|regex:([a-zA-ZñÑáéíóúÁÉÍÓÚ\s]+)',
            'resumen' => 'required|regex:([a-zA-ZñÑáéíóúÁÉÍÓÚ\s]+)',
            'año' =>'numeric|required|',
            'foto' =>'required|image|max:2048',
        ]);



        $pelicula = new Pelicula;

    $pelicula->titulo=$request->input('titulo');
    $pelicula->resumen=$request->input('resumen');
    $pelicula->año=$request->input('año');


    $pelicula = new Pelicula;

    $pelicula=$request->except('_token');
    if($request->hasfile('foto'));{
        $pelicula['foto']=$request->file('foto')->store('uploads', 'public');
    }
    Pelicula::insert($pelicula);
    return redirect()->route('pelicula.index');

}

/**
     * Display the specified resource.
     *
     * @param  \App\Models\Pelicula  $pelicula
     * @return \Illuminate\Http\Response
     */
    public function show(Pelicula $pelicula)
    {
        return view('pelicula.show',compact($pelicula));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Pelicula  $pelicula
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $pelicula=Pelicula::findOrfail($id);
        return view('pelicula.edit',compact('pelicula'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Pelicula  $pelicula
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'titulo' => 'required|regex:([a-zA-ZñÑáéíóúÁÉÍÓÚ\s]+)',
            'resumen' => 'required|regex:([a-zA-ZñÑáéíóúÁÉÍÓÚ\s]+)',
            'año' =>'numeric|required|',

        ]);
        $pelicula=Pelicula::findOrfail($id);
        $pelicula->titulo=$request->input('titulo');
        $pelicula->foto=$request->input('foto');
    $pelicula->resumen=$request->input('resumen');
    $pelicula->año=$request->input('año');
    $pelicula->save();
    return redirect()->route('pelicula.index');


    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Pelicula  $pelicula
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $pelicula=Pelicula::findOrfail($id );
        $pelicula->delete($id);
        return redirect()->route('pelicula.index');

    }
}
