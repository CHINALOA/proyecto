<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PDFcontroller extends Controller
{
    public function PDF(){
        $pdf = \PDF::loadview('prueba');
        $pdf->download('prueba.pdf');
    }
}
