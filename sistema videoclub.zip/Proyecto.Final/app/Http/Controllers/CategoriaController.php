<?php

namespace App\Http\Controllers;

use App\Models\Categoria;
use Illuminate\Validation\ValidationException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class CategoriaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $texto=trim($request->get('texto'));
     $categorias=DB::table('categoria')
    ->select('id', 'categoria',)
    ->where('id', 'LIKE', '%'.$texto.'%')
    ->orWhere('categoria', 'LIKE', '%'.$texto. '%')
    ->orderBy('id', 'asc')
    ->paginate(10);
     return view('categoria.index',compact('categorias', 'texto'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('categoria.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'categoria' => 'required|unique:categoria|regex:([a-zA-ZñÑáéíóúÁÉÍÓÚ\s]+)',
        ]);

        $categoria = new Categoria;
    $categoria->categoria=$request->input('categoria');
    $categoria->save();
    return redirect()->route('categoria.index');



    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Categoria
     * @return \Illuminate\Http\Response
     */
    public function show(Categoria $categoria)
    {
        return view('pelicula.show',compact($categoria));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Categoria
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $categoria=Categoria::findOrfail($id);
        return view('categoria.edit',compact('categoria'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Categoria  $pelicula
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'categoria' => 'required|regex:([a-zA-ZñÑáéíóúÁÉÍÓÚ\s]+)',
        ]);
        $categoria=Categoria::findOrfail($id);
        $categoria->categoria=$request->input('categoria');
    $categoria->save();
    return redirect()->route('categoria.index');


    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Categoria
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $categoria=Categoria::findOrfail($id);
        $categoria->delete();
        return redirect()->route('categoria.index');

    }
}
