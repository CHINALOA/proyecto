<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pelicula extends Model
{
    protected $table="pelicula";
    protected $PrimariKey="id_pelicula";
    protected $fillable = ['titulo','foto', 'resumen', 'año',
];
public $timestamps = false;
}
