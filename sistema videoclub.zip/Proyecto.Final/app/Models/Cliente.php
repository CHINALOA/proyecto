<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cliente extends Model
{
    protected $table="cliente";
    protected $PrimariKey="id_cliente";
    protected $fillable = [    'apellido', 'nombre', 'documento', 'telefono','email', 'direccion'
    ];

    public $timestamps = false;
}
